# Copyright ©2012


Material licenciado por la _Academia de Software Libre_([ADSL](http://adsl.org.mx/)) bajo atribución [_**Creative Commons** 2.5 México (CC BY 2.5)_](http://creativecommons.org/licenses/by/2.5/mx/). Usted es libre de copiarlo, distribuirlo y modificarlo, siempre y cuando haga referencia a este [repositorio](https://github.com/mundoSICA/tutorial_hispano_jQuery/tree/gh-pages) a la vez que atribuya la autoría a [fitorec](http://github.com/fitorec).

Si altera, transforma o crea una obra derivada, deberá distribuir el resultado bajo una licencia igual, similar o compatible. Cualquiera de las condiciones mencionadas pueden no aplicarse si obtiene permisos del autor. Para cualquier reutilización o distribución, deberá dejar en claro la licencia la mejor manera para hacerlo es a través de un enlace hacia la licencia [_**Creative Commons** 2.5 México (CC BY 2.5)_](http://creativecommons.org/licenses/by/2.5/mx/).
