# Document Object Model

Imagina que tienes el siguiente documento:

	<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
		"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
	<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
	<head>
		<title>Titulo Documento</title>
	</head>
	<body>
		<h1>Documento prueba</h1>
		<p>Esto solo es un documento de prueba</p>
	</body>
	</html>


